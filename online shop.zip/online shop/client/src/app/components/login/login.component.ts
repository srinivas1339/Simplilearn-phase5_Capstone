import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService } from 'src/app/services/cart/cart.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
    email: new FormControl("", [Validators.required, Validators.email]),
    password: new FormControl("", [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d).{8,}$/)])
  });

 
  constructor(public router: Router, public userService: UserService, public cartService: CartService) { }

  ngOnInit(): void {
  }

  loginBtnClickEventHandler() {
    let userCredentials = {
      email: this.loginForm.value.email,
      password: this.loginForm.value.password
    }
    this.userService.doUserValidation(userCredentials)
      .subscribe(
        (data) => {
          if (data) {
            this.cartService.getItemsCount(data["_id"]);
            this.userService.setName(data["name"]);
            this.userService.setLogInStatus(true);
            this.userService.setUserId(data["_id"]);
            this.router.navigateByUrl("/");
          }
        },
        (err) => {
          if(err.status === 401){
            this.setMessage("You have entered incorrect credentials",-1);
          }
          else{
            this.setMessage("Something went wrong. Please try again later.",-1);
          }
        }
      )
  }

  setMessage(msg,type) {
    let div = document.getElementById("message");
    div.innerHTML = "";
    let span = document.createElement("span");
    let textNode = document.createTextNode(msg);
    span.append(textNode);
    div.append(span);
    div.classList.replace("d-none","d-block")
    if(type==1){
      div.classList.remove("error");
      div.classList.add("success")
    }
    else{
      div.classList.remove("success");
      div.classList.add("error")
    }
  }
}